/*! ***************************************************************************
 *
 * \brief     Chip temperature functions
 * \file      chip_temperature.cpp
 * \author    Hugo Arends
 * \date      August 2025
 *
 * \note      The accuracy of the temperature measurement is ±10°C.
 *
 * \copyright 2025 HAN University of Applied Sciences. All Rights Reserved.
 *            \n\n
 *            Permission is hereby granted, free of charge, to any person
 *            obtaining a copy of this software and associated documentation
 *            files (the "Software"), to deal in the Software without
 *            restriction, including without limitation the rights to use,
 *            copy, modify, merge, publish, distribute, sublicense, and/or sell
 *            copies of the Software, and to permit persons to whom the
 *            Software is furnished to do so, subject to the following
 *            conditions:
 *            \n\n
 *            The above copyright notice and this permission notice shall be
 *            included in all copies or substantial portions of the Software.
 *            \n\n
 *            THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *            EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 *            OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *            NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 *            HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 *            WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *            FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 *            OTHER DEALINGS IN THE SOFTWARE.
 *
 *****************************************************************************/
#include "chip_temperature.h"

#include <avr/boot.h>
#include <avr/io.h>

// -----------------------------------------------------------------------------
// Local type definitions
// -----------------------------------------------------------------------------
#define ADC_CHANNEL (8)

// Check selected ADC channel for validity
#if (ADC_CHANNEL < 0) || (ADC_CHANNEL > 15)
#error Invalid ADC channel selected
#endif

// -----------------------------------------------------------------------------
// Local function prototypes
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// Local variables
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// Local function implementation
// -----------------------------------------------------------------------------

int16_t chip_temperature_read(void)
{
    // Initialize the ADC peripheral
    // ADC Multiplexer Selection Register:
    //   REFS[1:0] = 11   : Internal 1.1V voltage reference
    //   ADLAR     = 0    : Right adjust result
    //   MUX[3:0]  = nnnn : Select temperature sensor
    ADMUX = (1<<REFS1) | (1<<REFS0) | (ADC_CHANNEL);

    // ADC Control and Status Register A:
    //   ADEN      = 1   : ADC enable
    //   ADSC      = 1   : Start a conversion
    //   ADATE     = 0   : Auto triggering disabled
    //   ADIF      = 0   : Do not clear the interrupt flag
    //   ADIE      = 0   : Do not enable interrupts
    //   ADPS[2:0] = 111 : Prescaler division factor 128
    ADCSRA = (1<<ADEN) | (1<<ADSC) | (1<<ADPS2) | (1<<ADPS1) | (1<<ADPS0);

    // Wait for the conversion to complete by polling the ADSC bit
    while((ADCSRA & (1<<ADSC)) != 0)
    {;}

    // Read the result
    uint16_t val = ADC;

    // Calculate the temperature in degrees Celcius
    // The datasheet mentions in Section 23.7 that measured voltage has a
    // linear relationship to the temperature. If two values are known, we can derive the
    // linear equation. The table in the datsheet provides three typical values:
    // - -40°C  : 0x010D (269) => -40 = 269a + b
    // - +25°C  : 0x0160 (352) =>  25 = 352a + b
    // - +125°C : 0x01E0 (480) => 125 = 480a + b
    //
    // These are three equations with two unknows, which can be solved as follows:
    //
    //  125 = 480a + b
    //   25 = 352a + b
    // --------------- -
    //  100 = 128a
    //
    // a = 100 / 128
    // a = 0.78125
    //
    // Substitute to find b:
    //
    // 125 = 480a + b
    // 125 = 375 + b
    // b = -250
    //
    // Result: Temperature = 0.78125 * ADC - 250
    //
    // Note. A more accurate result can be achieved by using callibration values.
    //       The values are stored in the signature row and can be read with the
    //       function boot_signature_byte_get() from the <avr/boot.h> library.
    //       The datasheet is, however, not clear in what signature byte
    //       corresponds to what callibration value. Especially table 26-5,
    //       because it displays address 0x002 twice?!
    //
    // Last but not least, use the ADC value to calculate the temparature.
    // Use (faster) integer math instead of using floating points. Note that
    // division by 64 is the same as a bitshift by 6.

    int16_t temperature = ((50 * val) >> 6) - 250;

    return temperature;
}
